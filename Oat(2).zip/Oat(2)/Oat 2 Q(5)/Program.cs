﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_2_Q_5_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite um numero: ");
            int numero = int.Parse(Console.ReadLine());

            if (numero>=0)
            {
                int resultado = numero * 2;
                Console.WriteLine("O dobro desse numero E " + resultado);
            }

            else
            {
                int resultado = numero * 3;
                Console.WriteLine("O triplo desse numero E " + resultado);
                Console.WriteLine();
            }

        }
    }
}
