﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_2_Q_11_
{
    internal class Program
    {
        public static int valor { get; private set; }

        static void Main(string[] args)
        {
            valor = 0;

            Console.WriteLine("Preço do produto: ");
            double produto = double.Parse(Console.ReadLine());
            Console.WriteLine("=======Condiçao de pagamento========");
            Console.WriteLine("(1) À vista em dinheiro ou cheque, recebe 10% de desconto\n(2) À vista no cartão de crédito, recebe 15% de desconto\n(3) Em duas vezes, preço normal de etiqueta sem juros\n(4) Em duas vezes, preço normal de etiqueta mais juros de 10%");
            Console.WriteLine("Opçao: ");
            int opcao = int.Parse(Console.ReadLine());

            if (opcao == 1) 
            {
                valor = (int) (produto - (produto * 10 / 100));
                Console.WriteLine("O produto com desconto de 10% vai ficar" + valor);

            }

            else if (opcao == 2)
            {
                valor = (int)(produto - (produto * 15 / 100));
                Console.WriteLine("O produto com desconto de 15% vai ficar" + valor);
            }

            else if (opcao == 3)
            {
                Console.WriteLine("Quantas parcelas: ");
                int parcela = int.Parse(Console.ReadLine());
                valor = (int)(produto / parcela);
                Console.WriteLine("O preço do produto divido em" + parcela + "ficou em " + valor + " R$");
            }

            else if (opcao == 4)
            {
                Console.WriteLine("Quantas parcelas: ");
                int parcela = int.Parse(Console.ReadLine());
                valor = (int)(produto - (produto * 10 / 100));
                Console.WriteLine("O preço do produto divido em" + parcela + " ficou em" + valor + " R$");
                Console.WriteLine();
            }   
        }
    }
}
