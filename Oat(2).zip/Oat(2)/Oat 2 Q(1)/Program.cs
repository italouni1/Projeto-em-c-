﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_2_Q_1_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int soma = 0;

            Console.Write("Digite o valor de A: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Digite o valor de B: ");
            int b = int.Parse(Console.ReadLine());
            Console.Write("Digite o valor de C: ");
            int c = int.Parse(Console.ReadLine());
           
            soma = a + b;
            if (soma < c)
            {
                Console.WriteLine("O valor da soma de A + B e " + soma);
              
                Console.WriteLine("Portanto e menor que C que vale " + c);
            }

            else
            {
                Console.WriteLine("FIM");

            }
        }
    }
}
