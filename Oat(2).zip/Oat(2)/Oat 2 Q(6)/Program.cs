﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_2_Q_6_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool A;
            bool B;
            String resultado = String.Empty;
            int contador = 0;

            //validando valor a A

            do
            {
                if (contador != 0)
                    Console.WriteLine("Voce errou digite o valor de a true ou false");
                else
                    Console.WriteLine("Digite se o valor de a e true ou false");

                resultado = Console.ReadLine();
                bool.TryParse(resultado, out A);
                contador += 1;
            }
            while (resultado != "true" && resultado != "false");
            //validando valor de B

            resultado = string.Empty;
            contador = 0;
            do
            {
                if (contador != 0)
                    Console.WriteLine("Voce errou coloque se o valor de B e true ou false");
                else
                    Console.WriteLine("Digite se o valor de B e true ou false");

                resultado = Console.ReadLine().ToLower();
                bool.TryParse(resultado, out B);
                contador += 1;
            }
            while (resultado != "true" && resultado != "false");

            if (A == true)
                Console.WriteLine("A e verdadeiro");

            else
                Console.WriteLine("A e falso");

            if (B == true)
                Console.WriteLine("B e verdadeiro");
            else
                Console.WriteLine("B e falso");

            if (A == true && B == false || A == false && B == true)
                Console.WriteLine("A e diferente a B");

            else
                Console.WriteLine("A e igual a B");

            Console.ReadLine();






        
        }
    }
}
