﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_2_Q_4_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int soma = 0;
            int multiplicar = 0;
            int c = 0;
            Console.WriteLine("Digite o valor de A ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor de B ");
            int b = int.Parse(Console.ReadLine());

            if(a== b)
            {
                soma = a + b;
                c = soma;
                Console.WriteLine("O valor da soma de A + B e " + c);
                Console.WriteLine();
            }
            else
            {
                multiplicar = a * b;
                c = multiplicar;
                Console.Write("O valor da multiplicaçao de A * B e " + c);

                Console.WriteLine("=======");

            }
        }
    }
}
