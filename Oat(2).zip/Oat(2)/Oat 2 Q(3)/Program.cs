﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_2_Q_3_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite um numero aleatorio: ");
            int numero = int.Parse(Console.ReadLine());
            Console.WriteLine("==========================");

         if (numero % 2 == 0)
            {
                Console.WriteLine("Esse numero e par");
            }
         else
            {
                Console.WriteLine("Esse numero e impar");
                Console.WriteLine();
            }
        }
    }
}
