﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_2_Q_10_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Peso: ");
            double peso = double.Parse(Console.ReadLine());
            Console.Write("Altura ");
            double altura = double.Parse(Console.ReadLine());
            double imc = peso / (altura * altura);

            if (imc < 18.5)
            {
                Console.WriteLine("Seu imc e de " + imc + "Voce esta abaixo do peso");
            }

            else if (imc <= 25)
            {
                Console.WriteLine("Seu imc e de " + imc + "Voce esta com o peso normal");
            }

            else if (imc <= 30)
            {
                Console.WriteLine("Seu imc e de" + imc + "Voce esta acima do peso");
            }

            else {
                Console.WriteLine("Seu imc e de" + imc + "Voce esta obeso");
            }
        }   

    }
}
