﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_2_Q_7_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite um valor: ");
            int valor = int.Parse(Console.ReadLine());
            Console.WriteLine("======================");

            if (valor % 2 == 0)
            {
                int resultado = valor + 5;
                Console.WriteLine("O resultado dessa soma E " + resultado);
            }
            else
            {
                int resultado = valor + 8;
                Console.WriteLine("O resultado dessa soma E " + resultado);
                Console.WriteLine();

            }
        }
    }
}
