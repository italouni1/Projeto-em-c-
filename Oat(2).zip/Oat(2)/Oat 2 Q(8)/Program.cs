﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_2_Q_8_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o primeiro valor: ");
            int valor1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o segundo valor: ");
            int valor2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o terceiro valor: ");
            int valor3 = int.Parse(Console.ReadLine());
            Console.WriteLine("========================");

            if(valor1> valor2 && valor1> valor3)
            {
                if(valor2> valor3)
                {
                    Console.WriteLine(valor1);
                    Console.WriteLine(valor2);
                    Console.WriteLine(valor3);
                }

                else
                {
                    Console.WriteLine(valor1);
                    Console.WriteLine(valor3);
                    Console.WriteLine(valor2);

                }
                
                if (valor2 > valor1 && valor2 > valor3)
                {
                    if (valor1 > valor3)
                    {
                        Console.WriteLine(valor2);
                        Console.WriteLine(valor1);
                        Console.WriteLine(valor3);
                    }

                    else
                    {
                        Console.WriteLine(valor2);
                        Console.WriteLine(valor3);
                        Console.WriteLine(valor1);
                    }

                    if (valor3 > valor1 && valor3 > valor2)
                    {
                        if (valor1 > valor2)
                        {
                            Console.WriteLine(valor3);
                            Console.WriteLine(valor1);
                            Console.WriteLine(valor2);

                        }

                        else
                        {
                            Console.WriteLine(valor3);
                            Console.WriteLine(valor2);
                            Console.WriteLine(valor1);
                        }
                    }
                }
            }



        }
    }
}
