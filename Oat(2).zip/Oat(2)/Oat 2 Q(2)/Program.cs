﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oat_2_Q_2_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nome:");
            string nome = Console.ReadLine();
            Console.WriteLine("Sexo:");
            string sexo = Console.ReadLine();
            Console.WriteLine("Casado/Solteiro: ");
            string estado = Console.ReadLine();

            if (sexo =="f" && estado=="Casado")
            {
                Console.WriteLine("Quantos anos voce tem de casado?");
                int anos = int.Parse(Console.ReadLine());
                Console.WriteLine("Voce tem" + anos + "de casada");

            }
            else
            {
                Console.WriteLine("Obrigado" + nome + "por sua participacao");
                Console.WriteLine("========");
            }


        }
    }
}
